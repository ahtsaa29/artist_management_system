import 'package:artist_management_system/features/artist/domain/usecases/create_artist_usecase.dart';
import 'package:artist_management_system/features/artist/domain/usecases/delete_artisit_usecase.dart';
import 'package:artist_management_system/features/artist/domain/usecases/update_artist_usecase.dart';
import 'package:artist_management_system/features/song/domain/repository/song_repository.dart';
import 'package:artist_management_system/features/song/domain/usecases/create_song_usecase.dart';
import 'package:artist_management_system/features/song/domain/usecases/delete_song_usecase.dart';
import 'package:artist_management_system/features/song/domain/usecases/update_song_usecase.dart';
import 'package:artist_management_system/features/user/domain/usecases/delete_user_usecase.dart';
import 'package:artist_management_system/features/user/domain/usecases/update_user_usecase.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:get_it/get_it.dart';

// Auth
import 'features/auth/data/datasources/auth_remote_datasource.dart';
import 'features/auth/data/repositories/auth_repository_impl.dart';
import 'features/auth/domain/repository/auth_repository.dart';
import 'features/auth/domain/usecases/google_signin_user.dart';
import 'features/auth/domain/usecases/get_current_user.dart';
import 'features/auth/domain/usecases/login_user.dart';
import 'features/auth/domain/usecases/logout_user.dart';
import 'features/auth/domain/usecases/register_user.dart';
import 'features/auth/presentation/bloc/auth_bloc.dart';

//  Artist
import 'features/artist/data/datasources/artist_remote_datasource.dart';
import 'features/artist/data/repositories/artist_repository_impl.dart';
import 'features/artist/domain/repository/artist_repository.dart';
import 'features/artist/domain/usecases/watch_artist_usecase.dart';
import 'features/artist/presentation/bloc/artist_bloc.dart';

// Song
import 'features/song/data/datasources/song_remote_datasource.dart';
import 'features/song/data/repositories/song_repository_impl.dart';
import 'features/song/domain/usecases/watch_song_usecase.dart';
import 'features/song/presentation/bloc/song_bloc.dart';

// User
import 'features/user/data/datasources/user_remote_datasource.dart';
import 'features/user/data/repositories/user_repository_impl.dart';
import 'features/user/domain/usecases/watch_user_usecase.dart';
import 'features/user/presentation/bloc/user_bloc.dart';
import 'features/user/domain/repositories/user_repository.dart';

final sl = GetIt.instance;

Future<void> initDependencies() async {
  sl.registerLazySingleton(() => FirebaseAuth.instance);
  sl.registerLazySingleton(() => FirebaseFirestore.instance);

  sl.registerLazySingleton<AuthRemoteDataSource>(
    () => AuthRemoteDataSourceImpl(firebaseAuth: sl(), firestore: sl()),
  );
  sl.registerLazySingleton<AuthRepository>(
    () => AuthRepositoryImpl(remoteDataSource: sl()),
  );
  sl.registerLazySingleton(() => GetCurrentUser(sl()));
  sl.registerLazySingleton(() => LoginUser(sl()));
  sl.registerLazySingleton(() => RegisterUser(sl()));
  sl.registerLazySingleton(() => LogoutUser(sl()));
  sl.registerLazySingleton<GoogleSignInUser>(() => GoogleSignInUser(sl()));
  sl.registerFactory(
    () => AuthBloc(
      getCurrentUser: sl(),
      loginUser: sl(),
      registerUser: sl(),
      logoutUser: sl(),
      googleSignInUser: sl(),
    ),
  );

  // ─── Artist ────────────────────────────────────────────────────────────────
  sl.registerLazySingleton<ArtistRemoteDataSource>(
    () => ArtistRemoteDataSourceImpl(firestore: sl()),
  );
  sl.registerLazySingleton<ArtistRepository>(
    () => ArtistRepositoryImpl(remoteDataSource: sl()),
  );
  sl.registerLazySingleton(() => WatchArtists(sl()));
  sl.registerLazySingleton(() => CreateArtist(sl()));
  sl.registerLazySingleton(() => UpdateArtist(sl()));
  sl.registerLazySingleton(() => DeleteArtist(sl()));
  sl.registerFactory(
    () => ArtistBloc(
      watchArtists: sl(),
      createArtist: sl(),
      updateArtist: sl(),
      deleteArtist: sl(),
    ),
  );

  // ─── User ──────────────────────────────────────────────────────────────────
  sl.registerLazySingleton<UserRemoteDataSource>(
    () => UserRemoteDataSourceImpl(firestore: sl()),
  );
  sl.registerLazySingleton<UserRepository>(
    () => UserRepositoryImpl(remoteDataSource: sl()),
  );
  sl.registerLazySingleton(() => WatchUsers(sl()));
  sl.registerLazySingleton(() => UpdateUser(sl()));
  sl.registerLazySingleton(() => DeleteUser(sl()));
  sl.registerFactory(
    () => UserBloc(watchUsers: sl(), updateUser: sl(), deleteUser: sl()),
  );

  // ─── Song ──────────────────────────────────────────────────────────────────
  sl.registerLazySingleton(() => FirebaseStorage.instance);
  sl.registerLazySingleton<SongRemoteDataSource>(
    () => SongRemoteDataSourceImpl(firestore: sl(), storage: sl()),
  );
  sl.registerLazySingleton<SongRepository>(
    () => SongRepositoryImpl(remoteDataSource: sl()),
  );
  sl.registerLazySingleton(() => WatchSongsForArtist(sl()));
  sl.registerLazySingleton(() => CreateSong(sl()));
  sl.registerLazySingleton(() => UpdateSong(sl()));
  sl.registerLazySingleton(() => DeleteSong(sl()));
  sl.registerFactory(
    () => SongBloc(
      watchSongsForArtist: sl(),
      createSong: sl(),
      updateSong: sl(),
      deleteSong: sl(),
    ),
  );
}
